<?php

class Loans extends Eloquent {

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'loans';
                
                protected  $guarded = array('id');
 
                
}

